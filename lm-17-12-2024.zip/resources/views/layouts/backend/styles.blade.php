@vite(['resources/css/app.css', 'resources/js/app.js'])

<link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

@stack('custom_styles')
