<x-front-layout title="{{ __('Kids Minnie') }}">

</x-front-layout>
