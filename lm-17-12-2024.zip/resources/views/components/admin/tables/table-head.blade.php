
<thead class="bg-gray-50 dark:bg-gray-800">
    {{ $slot }}
</thead>
