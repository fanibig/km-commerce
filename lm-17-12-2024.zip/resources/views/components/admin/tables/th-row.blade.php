<th {!! $attributes->merge(['class' => 'px-3 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-white']) !!}>
    {{ $slot }}
</th>
