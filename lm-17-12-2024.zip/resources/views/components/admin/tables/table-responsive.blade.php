<div class="flex flex-col">
    <div class="overflow-x-auto">
        <div class="py-2 align-middle inline-block min-w-full">
            <div class="shadow overflow-hidden border border-gray-200 sm:rounded-lg dark:border-gray-800">
                {{ $table }}
            </div>
        </div>
    </div>
</div>
