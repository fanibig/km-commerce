<td {!! $attributes->merge(['class' => 'px-2 py-2 text-gray-800 dark:text-white']) !!}>
    {{ $slot }}
</td>
