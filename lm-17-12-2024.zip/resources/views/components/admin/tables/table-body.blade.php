<tbody class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-400">
    {{ $slot }}
</tbody>
