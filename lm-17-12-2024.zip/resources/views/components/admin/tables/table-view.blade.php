<x-admin.tables.table-responsive>
    <x-slot name="table">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-400">
            {{ $thead }}
            {{ $tbody }}
        </table>
    </x-slot>

</x-admin.tables.table-responsive>
