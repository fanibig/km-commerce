<?php

return [
    Barryvdh\Debugbar\ServiceProvider::class,
    App\Providers\AppServiceProvider::class,
    App\Providers\SettingServiceProvider::class,
    App\Providers\RepositoriesServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,
];