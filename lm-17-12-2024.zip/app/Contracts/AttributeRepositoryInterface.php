<?php

namespace App\Contracts;

interface AttributeRepositoryInterface
{
    //
}
